/*初始化水印*/
const userName = '苏金苗互通2'
const loginTime = '2023-05-19 14:25'
window.onload = function(){
  watermark.init({
    watermark_txt: `宁夏免疫规划信息系统-${userName}-${loginTime}`,
    // watermark_color:'#5579ee',            //水印字体颜色
    // watermark_fontsize:'24px',          //水印字体大小
    watermark_alpha: 0.2,               //水印透明度，要求设置在大于等于0.005
    // watermark_angle:135,                 //水印倾斜度数
    watermark_width: 460,                //水印宽度
    watermark_height: 180,               //水印长度
  });
}

// watermark.init({ watermark_txt: "测试水印，1021002301，测试水印，100101010111101" , watermark_width: 200});

/*移除水印*/
document.getElementById('remove-watermark').addEventListener("click",function () {
    watermark.remove();
},true)


/*添加水印*/
document.getElementById('add-watermark').addEventListener("click",function () {
    watermark.load({  
      watermark_txt: `宁夏免疫规划信息系统-${userName}-${loginTime}`,
    // watermark_color:'#5579ee',            //水印字体颜色
    // watermark_fontsize:'24px',          //水印字体大小
    watermark_alpha: 0.2,               //水印透明度，要求设置在大于等于0.005
    // watermark_angle:135,                 //水印倾斜度数
    watermark_width: 460,                //水印宽度
    watermark_height: 180,               //水印长度
  });
},true)
